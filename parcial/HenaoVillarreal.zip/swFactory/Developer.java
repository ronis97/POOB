public class Developer {
	private String name;
	private int code;
}
