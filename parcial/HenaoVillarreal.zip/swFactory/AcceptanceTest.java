import java.util.*;
public class AcceptanceTest
{
    private String description;
    private int AcceptancePercentage;
    /**
     * Borra una prueba
     */
    public void deleteATest(){
    
    }
}
