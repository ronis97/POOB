public class Requirement {
    private String urlDetail;
    private int maxPoints;
    private HumanEvaluator evaluator;
    /**
     * Borra el requerimiento
     * @return Si el requerimiento fue borrado exitosamente
     */
    public boolean deleteRequirements(){
        return true;
    }
}
