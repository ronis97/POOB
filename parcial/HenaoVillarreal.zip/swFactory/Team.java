import java.util.ArrayList;
public class Team {
    private String nickname;
    private ArrayList<Developer> members;
    /**
     * notifica a los miembros del equipo
     * @return si los miembros del equipo fueron notificados 
     * exitosamente
     */
    public boolean notifyDevelopers(){
        return false;
    }
}
