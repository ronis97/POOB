public class UnitTest {

	private AutomaticEvaluator automaticEvaluator;

	public int runTest(String appUrl, Requirement r) {
		return 0;
	}

}
