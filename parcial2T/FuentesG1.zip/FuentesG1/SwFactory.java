import java.util.Collection;

public class SwFactory {

	private String[] clients;

	private Collection<Team> teams;

	private Collection<Project> projects;

	private Collection<Inscription> inscriptions;

	private Collection<Certificates> certificates;

	private Collection<Feedbacker> feedbackers;

}
