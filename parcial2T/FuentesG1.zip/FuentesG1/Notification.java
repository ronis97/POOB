import java.time.LocalDate;

public class Notification {

	private LocalDate date;

	private String subject;

	private int points;

	private Inscription inscription;

}
