public class Developer {

	private String name;

	private int code;

	private Team team;

	private Certificates certificates;

}
