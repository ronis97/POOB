import java.time.LocalDate;
import java.util.Collection;

public class Certificates {

	private int number;

	private LocalDate date;

	private int points;

	private int wonProjects;

	private Developer developer;

	private SwFactory swFactory;

	private Collection<Project> wonProjects;

}
