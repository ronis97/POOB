public abstract class Evaluator {

	private Requirement requirement;

	/**
	 *  
	 */
	public static int evaluate(Requirement r, String appUrl) {
		return 0;
	}

}
