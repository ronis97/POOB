public interface Feedbacker {

    //private SwFactory swFactory;

    /**
     * Return 1 to 100 depends of the experience into application
     * 
     *  
     */
    //public static abstract int calculateExperience();

}
